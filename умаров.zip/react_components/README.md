# Задачи на создание компонентов в React

Проект содержит компоненты Greeting, TaskList, ActionButton, ProfileCard и ImageGallery, подключённые в App.

## Запуск

1. Установить Node.js.
2. В папке проекта выполнить `npm install`.
3. Выполнить `npm run dev` и открыть адрес, указанный Vite.
4. Для production-сборки выполнить `npm run build`.
