export default function ActionButton() {
  return (
    <section className="section">
      <h2>Кнопка</h2>
      <button type="button">Нажми меня</button>
      <p>Кнопка пока не нажата.</p>
    </section>
  );
}
