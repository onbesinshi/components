const skills = ['HTML', 'CSS', 'React'];

export default function ProfileCard() {
  return (
    <section className="section profile-card">
      <h2>Анна Иванова</h2>
      <h3>Веб-разработчик</h3>
      <p>Люблю писать чистый код и изучать новые технологии</p>
      <ul>
        {skills.map((skill) => <li key={skill}>{skill}</li>)}
      </ul>
    </section>
  );
}
