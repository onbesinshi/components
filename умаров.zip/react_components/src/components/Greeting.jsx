export default function Greeting() {
  return (
    <section className="section">
      <h1>Привет, мир!</h1>
      <p>Это мой первый React-компонент.</p>
    </section>
  );
}
