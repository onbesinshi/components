const images = [
  {
    src: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=600&auto=format&fit=crop',
    alt: 'Горное озеро и лес',
  },
  {
    src: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=600&auto=format&fit=crop',
    alt: 'Пейзаж с горами на закате',
  },
  {
    src: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600&auto=format&fit=crop',
    alt: 'Солнечный свет в лесу',
  },
];

export default function ImageGallery() {
  return (
    <section className="section">
      <h2>Галерея изображений</h2>
      <div className="image-gallery">
        {images.map((image) => (
          <img key={image.src} src={image.src} alt={image.alt} />
        ))}
      </div>
    </section>
  );
}
