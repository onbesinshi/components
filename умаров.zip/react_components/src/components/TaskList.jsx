const tasks = [
  'Позавтракать',
  'Проверить почту',
  'Сделать зарядку',
  'Выпить стакан воды',
];

export default function TaskList() {
  return (
    <section className="section">
      <h2>Список задач</h2>
      <ul>
        {tasks.map((task) => <li key={task}>{task}</li>)}
      </ul>
    </section>
  );
}
