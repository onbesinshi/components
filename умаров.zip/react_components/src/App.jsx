import Greeting from './components/Greeting.jsx';
import TaskList from './components/TaskList.jsx';
import ActionButton from './components/ActionButton.jsx';
import ProfileCard from './components/ProfileCard.jsx';
import ImageGallery from './components/ImageGallery.jsx';

export default function App() {
  return (
    <main className="app">
      <Greeting />
      <TaskList />
      <ActionButton />
      <ProfileCard />
      <ImageGallery />
    </main>
  );
}
